package com.example.Spring_h2_03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringH203ApplicationTests {

	@Test
	void contextLoads() {
	}

}
