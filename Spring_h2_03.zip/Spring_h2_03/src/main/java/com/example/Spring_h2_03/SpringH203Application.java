package com.example.Spring_h2_03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringH203Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringH203Application.class, args);
	}

}
